Installation
============
1. Put all these files into **one** folder, preferably (but not necessarily) accessible through PATH, e.g. ~/bin/
2. Make all .sh files executable

Usage
=====

## To find proposed new version number, run:

~/bin/find-latest-tag.sh

*Hint*: the script also prints command to tag this new version

## To tag new version, run

~/bin/tag-version.sh [version-without-v]

*Hint*: the script also prints notification to be posted to Slack


